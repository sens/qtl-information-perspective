"genetic.dist" <-
function(theta)
  {
    -0.5*log(1-2*theta)
  }

